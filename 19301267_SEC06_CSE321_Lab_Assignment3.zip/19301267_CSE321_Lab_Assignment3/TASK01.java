class Task1 extends Thread{
    public void run() {
		for(int k=1; k<=30; k++) {
			System.out.println("Output from:" + getName() + ": " + k);
			if (i==10) {
				
				task1_2 mythread2 = new task1_2();
				mythread2.start();
				
				try {
					mythread2.join();
				} catch (InterruptedException e) {
					
					e.printStackTrace();
				}
				k=20;
			}
			try {
				sleep(1000);
			} catch (InterruptedException e) {
				
				e.printStackTrace();
			}
		}	
    }
}

class Task1_2 extends Thread{
	@Override
    public void run() {
		
		for(int k=11; k<=20; k++) {
			System.out.println("Output from:" + getName() + ": " + k);
			try {
				sleep(1000);
			} catch (InterruptedException e) {
				
				e.printStackTrace();
			}
		}
		
    }	
}

public class Task1 {

	public static void main(String[] args) {
		
		
		
		Task1 mythread1 = new Task1();
		
		
		mythread1.run();
		
	}

}
