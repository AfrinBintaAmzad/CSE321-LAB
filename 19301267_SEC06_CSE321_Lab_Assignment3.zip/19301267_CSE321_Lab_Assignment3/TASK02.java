
package Task2;

class zero extends Thread{
	
	
	public static int imaxDivisors;
	public static int inumwithmax;
	
	@Override
    public void run() {
	
		   int icount;
		   
		             imaxDivisors = 1; 
		   
		             inumwithmax = 1;
		   
		         for ( icount = 1;  icount  <= 10000;  icount ++ ) {
		   
		                int X; 
		   
		                int idivisorCount; 
		   
		                 idivisorCount = 0;
		   
		             for ( X = 1;  X <= icount;  X++ ) {
		   
		               if ( icount % X == 0 )
		   
		                       idivisorCount++;
		   
		                 }
		                 if (idivisorCount > imaxDivisors) {
		   
		                    imaxDivisors = idivisorCount;
		   
		                    inumwithmax = icount;
		   
		                 }
		             }
		   
		              
		             System.out.println("integers between 1 and 10000");
		   
		             System.out.println("The maximum number of divisors are " + imaxDivisors);
		   
		             System.out.println("A number with " + imaxDivisors + " divisors is " +
		   
		              inumwithmax +" from "+ getName());
		
    }
	
}

class one extends Thread{
	
	public static int imaxDivisors;
	public static int inumwithmax;
	
	@Override
    public void run() {
	
		   int icount;
		   
		             imaxDivisors = 1; 
		   
		             inumwithmax = 1;
		   
		         for ( icount = 10001;  icount  <= 20000;  icount ++ ) {
		   
		                int X; 
		   
		                int idivisorCount; 
		   
		                 idivisorCount = 0;
		   
		             for ( X = 1;  X <= icount;  X++ ) {
		   
		               if ( icount % X == 0 )
		   
		                       idivisorCount++;
		   
		                 }
		   
		                  
		   
		                 if (idivisorCount > imaxDivisors) {
		   
		                    imaxDivisors = idivisorCount;
		   
		                    inumwithmax = icount;
		   
		                 }
		             }
		   
		              
		             System.out.println("integers between 10001 and 20000");
		   
		             System.out.println("The maximum number of divisors are " + imaxDivisors);
		   
		             System.out.println("A number with " + imaxDivisors + " divisors is " +
		   
		              inumwithmax +" from "+ getName());
		
    }
	
}

class two extends Thread{
	
	public static int imaxDivisors;
	public static int inumwithmax;
	
	@Override
    public void run() {
	
		   int icount;
		   
		             imaxDivisors = 1; 
		   
		             inumwithmax = 1;
		   
		         for ( icount = 20001;  icount  <= 30000;  icount ++ ) {
		   
		                int X; 
		   
		                int idivisorCount; 
		   
		                 idivisorCount = 0;
		   
		             for ( X = 1;  X<= icount;  X++ ) {
		   
		               if ( icount % X == 0 )
		   
		                       idivisorCount++;
		   
		                 }
		                 if (idivisorCount > imaxDivisors) {
		   
		                    imaxDivisors = idivisorCount;
		   
		                    inumwithmax = icount;
		   
		                 }
		             }
		   
		              
		             System.out.println("integers between 20001 and 30000");
		   
		             System.out.println("The maximum number of divisors are " + imaxDivisors);
		   
		             System.out.println("A number with " + imaxDivisors + " divisors is " +
		   
		              inumwithmax +" from "+ getName());
		
    }
	
}


class three extends Thread{
	
	public static int imaxDivisors;
	public static int inumwithmax;
	
	@Override
    public void run() {
	
		   int icount;
		   
		             imaxDivisors = 1; 
		   
		             inumwithmax = 1;
		   
		         for ( icount = 30001;  icount  <= 40000;  icount ++ ) {
		   
		                int X; 
		   
		                int idivisorCount; 
		   
		                 idivisorCount = 0;
		   
		             for ( X= 1;  X<= icount;  X++ ) {
		   
		               if ( icount % X == 0 )
		   
		                       idivisorCount++;
		   
		                 }
		   
		                 if (idivisorCount > imaxDivisors) {
		   
		                    imaxDivisors = idivisorCount;
		   
		                    inumwithmax = icount;
		   
		                 }
		             }
		   
		              
		             System.out.println("integers between 30001 and 40000");
		   
		             System.out.println("The maximum number of divisors are " + imaxDivisors);
		   
		             System.out.println("A number with " + imaxDivisors + " divisors is " +
		   
		              inumwithmax +" from "+ getName());
		
    }
	
}



class four extends Thread{
	
	public static int imaxDivisors;
	public static int inumwithmax;
	
	@Override
    public void run() {
	
		   int icount;
		   
		             imaxDivisors = 1; 
		   
		             inumwithmax = 1;
		   
		         for ( icount = 40001;  icount  <= 50000;  icount ++ ) {
		   
		                int X; 
		   
		                int idivisorCount; 
		   
		                 idivisorCount = 0;
		   
		             for ( X= 1;  X<= icount;  X++ ) {
		   
		               if ( icount %X== 0 )
		   
		                       idivisorCount++;
		   
		                 }
		   
		                 if (idivisorCount > imaxDivisors) {
		   
		                    imaxDivisors = idivisorCount;
		   
		                    inumwithmax = icount;
		   
		                 }
		             }
		   
		              
		             System.out.println("integers between 40001 and 50000");
		   
		             System.out.println("The maximum number of divisors are " + imaxDivisors);
		   
		             System.out.println("A number with " + imaxDivisors + " divisors is " +
		   
		              inumwithmax +" from "+ getName());
		
    }
	
}


class five extends Thread{
	
	public static int imaxDivisors;
	public static int inumwithmax;
	
	@Override
    public void run() {
	
		   int icount;
		   
		             imaxDivisors = 1; 
		   
		             inumwithmax = 1;
		   
		         for ( icount = 50001;  icount  <= 60000;  icount ++ ) {
		   
		                int X; 
		   
		                int idivisorCount; 
		   
		                 idivisorCount = 0;
		   
		             for ( X= 1;  X<= icount;  X++ ) {
		   
		               if ( icount %X== 0 )
		   
		                       idivisorCount++;
		   
		                 }
		   
		                  
		   
		                 if (idivisorCount > imaxDivisors) {
		   
		                    imaxDivisors = idivisorCount;
		   
		                    inumwithmax = icount;
		   
		                 }
		   
		              
		   
		             }
		   
		              
		             System.out.println("integers between 50001 and 60000");
		   
		             System.out.println("The maximum number of divisors are " + imaxDivisors);
		   
		             System.out.println("A number with " + imaxDivisors + " divisors is " +
		   
		              inumwithmax +" from "+ getName());
		
    }
	
}

class six extends Thread{
	
	public static int imaxDivisors;
	public static int inumwithmax;
	
	@Override
    public void run() {
	
		   int icount;
		   
		             imaxDivisors = 1; 
		   
		             inumwithmax = 1;
		   
		         for ( icount = 60001;  icount  <= 70000;  icount ++ ) {
		   
		                int X; 
		   
		                int idivisorCount; 
		   
		                 idivisorCount = 0;
		   
		             for ( X= 1;  X<= icount;  X++ ) {
		   
		               if ( icount %X== 0 )
		   
		                       idivisorCount++;
		   
		                 }
		   
		                  
		   
		                 if (idivisorCount > imaxDivisors) {
		   
		                    imaxDivisors = idivisorCount;
		   
		                    inumwithmax = icount;
		   
		                 }
		   
		              
		   
		             }
		   
		              
		             System.out.println("integers between 60001 and 70000");
		   
		             System.out.println("The maximum number of divisors are " + imaxDivisors);
		   
		             System.out.println("A number with " + imaxDivisors + " divisors is " +
		   
		              inumwithmax +" from "+ getName());
		
    }
	
}


class seven extends Thread{
	
	public static int imaxDivisors;
	public static int inumwithmax;
	
	@Override
    public void run() {
	
		   int icount;
		   
		             imaxDivisors = 1; 
		   
		             inumwithmax = 1;
		   
		         for ( icount = 70001;  icount  <= 80000;  icount ++ ) {
		   
		                int X; 
		   
		                int idivisorCount; 
		   
		                 idivisorCount = 0;
		   
		             for ( X= 1;  X<= icount;  X++ ) {
		   
		               if ( icount %X == 0 )
		   
		                       idivisorCount++;
		   
		                 }
		   
		                  
		   
		                 if (idivisorCount > imaxDivisors) {
		   
		                    imaxDivisors = idivisorCount;
		   
		                    inumwithmax = icount;
		   
		                 }
		   
		              
		   
		             }
		   
		              
		             System.out.println("integers between 70001 and 80000");
		   
		             System.out.println("The maximum number of divisors are " + imaxDivisors);
		   
		             System.out.println("A number with " + imaxDivisors + " divisors is " +
		   
		              inumwithmax +" from "+ getName());
		
    }
	
}

class eight extends Thread{
	
	public static int imaxDivisors;
	public static int inumwithmax;
	
	@Override
    public void run() {
	
		   int icount;
		   
		             imaxDivisors = 1; 
		   
		             inumwithmax = 1;
		   
		         for ( icount = 80001;  icount  <= 90000;  icount ++ ) {
		   
		                int X; 
		   
		                int idivisorCount; 
		   
		                 idivisorCount = 0;
		   
		             for ( X= 1;  X<= icount;  X++ ) {
		   
		               if ( icount %X== 0 )
		   
		                       idivisorCount++;
		   
		                 }
		   
		                 if (idivisorCount > imaxDivisors) {
		   
		                    imaxDivisors = idivisorCount;
		   
		                    inumwithmax = icount;
		   
		                 }
		             }
		   
		              
		             System.out.println("integers between 80001 and 90000");
		   
		             System.out.println("The maximum number of divisors are " + imaxDivisors);
		   
		             System.out.println("A number with " + imaxDivisors + " divisors is " +
		   
		              inumwithmax +" from "+ getName());
		
    }
	
}


class nine extends Thread{
	
	public static int imaxDivisors;
	public static int inumwithmax;

    public void run() {
	
		   int icount;
		   
		             imaxDivisors = 1; 
		   
		             inumwithmax = 1;
		   
		         for ( icount = 90001;  icount  <= 100000;  icount ++ ) {
		   
		                int X; 
		   
		                int idivisorCount; 
		   
		                 idivisorCount = 0;
		   
		             for ( X= 1;  X<= icount;  X++ ) {
		   
		               if ( icount % X== 0 )
		   
		                       idivisorCount++;
		   
		                 }
		                 if (idivisorCount > imaxDivisors) {
		   
		                    imaxDivisors = idivisorCount;
		   
		                    inumwithmax = icount;
		   
		                 }
		   
		             }
		        
		             System.out.println("integers between 90001 and 100000");
		   
		             System.out.println("The maximum number of divisors are " + imaxDivisors);
		   
		             System.out.println("A number with " + imaxDivisors + " divisors is " +
		   
		              inumwithmax +" from "+ getName());
		
    }
	
}


public class Task2 {

	public static void main(String[] args) {
		
		int finalnum = 0;
		int finaldivnum = 0;
		
		zero z = new zero();
		z.run();
		if(z.imaxDivisors > finaldivnum) {
			finaldivnum = z.imaxDivisors;
			finalnum = z.inumwithmax;
		}
		
		System.out.println("  ");
		
		one o = new one();
		o.run();
		if(o.imaxDivisors > finaldivnum) {
			finaldivnum = o.imaxDivisors;
			finalnum = o.inumwithmax;
		}
		
		System.out.println("  ");
		
		two t = new two();
		t.run();
		if(t.imaxDivisors > finaldivnum) {
			finaldivnum = t.imaxDivisors;
			finalnum = t.inumwithmax;
		}
		
		System.out.println("  ");
		
		three th = new three();
		th.run();
		if(th.imaxDivisors > finaldivnum) {
			finaldivnum = th.imaxDivisors;
			finalnum = th.inumwithmax;
		}
		
		System.out.println("  ");
		
		four f = new four();
		f.run();
		if(f.imaxDivisors > finaldivnum) {
			finaldivnum = f.imaxDivisors;
			finalnum = f.inumwithmax;
		}
		
		System.out.println("  ");
		
		five fi = new five();
		fi.run();
		if(fi.imaxDivisors > finaldivnum) {
			finaldivnum = fi.imaxDivisors;
			finalnum = fi.inumwithmax;
		}
		
		System.out.println("  ");
		
		six s = new six();
	    s.run();
	    if(s.imaxDivisors > finaldivnum) {
			finaldivnum = s.imaxDivisors;
			finalnum = s.inumwithmax;
		}

	    
	    System.out.println("  ");
		
		seven se = new seven();
	    se.run();
	    if(se.imaxDivisors > finaldivnum) {
			finaldivnum = se.imaxDivisors;
			finalnum = se.inumwithmax;
		}
   
	    System.out.println("  ");
		
		eight e = new eight();
	    e.run();
	    if(e.imaxDivisors > finaldivnum) {
			finaldivnum = e.imaxDivisors;
			finalnum = e.inumwithmax;
		}

		
	    System.out.println("  ");
		
		nine n = new nine();
	    n.run();
	    if((n.imaxDivisors > finaldivnum) || (n.inumwithmax > finalnum)) {
			finaldivnum = n.imaxDivisors;
			finalnum = n.inumwithmax;
			
		}

	    System.out.println("  ");
	 
	    System.out.println(finalnum + " got the largest number of divisors from the results from Thread-0 to Thread-9 and divisor number is: " + finaldivnum);
	
	}
}
   

