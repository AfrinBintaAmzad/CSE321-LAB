#! /bin/bash
echo "what is your annual income : "
read income
if [ $income -lt 240000 ] || [ $income -eq 240000 ];
then 
echo " TAX : 0"
elif [ $income -lt 540000 ] || [ $income -eq 540000 ];
then
percentageoftax=$(( $income - 240000 ))
taxation=$(( $taxation* 10 ))
tax=$(( $tax / 100))
echo " TAX : $tax "
elif [ $income -lt 720000 ] || [ $income -eq 720000 ];
then
pecentage=$(( $income - 540000 ))
taxation=$(( $percentage * 20 ))
tax=$(( $taxhobe / 100))
pay=$(($tax + 30000 ))
echo " TAX : $pay "
elif [ $income -gt 720000 ];
then 
percentage=$(( $income - 720000 ))
taxation=$(( $percentage * 30 ))
tax=$(( $taxhobe / 100))
pay=$(( $tax + 66000  ))
echo " TAX : $pay "
fi
