#! /bin/bash
echo "Please Enter a number :"
read Num
if [ `expr $Num % 5 ` -eq 0 ] || [ `expr $Num % 2 ` -eq 0 ] ;
then 
if [ `expr $Num % 5 ` -eq 0 ] && [ `expr $Num % 2 ` -eq 0 ];
then 
echo "$Num no"
else 
echo "$Num yes "
fi
fi
if [ `expr $Num % 5 ` != 0 ] && [ `expr $Num % 2 ` != 0 ];
then 
echo "Ignore "
fi 
