#! /bin/bash 
echo "Which operation would you like to do ?"
read operation 
echo "Operand 1: "
read O1
echo "Operand 2: "
read O2
addition () {
echo " The result is $(($O1 + $O2))"
}
Multiplication() {
echo " The result is $(($O1 * $O2))"
}
Divide () {
echo " The result is $(($O1 / $O2))"
}
Subtraction () {
echo " The result is $(($O1 - $O2))"
}
if [[ "$operation" == "+" ]];
then 
addition $O1 $O2

elif [[ "$operation" == "*" ]];
then
Multiplication $O1 $O2
elif [[ "$operation" == "/" ]];
then 
Divide $O1 $O2
elif [[ "$operation" == "-" ]];
then 
Subtraction $O1 $O2
fi

