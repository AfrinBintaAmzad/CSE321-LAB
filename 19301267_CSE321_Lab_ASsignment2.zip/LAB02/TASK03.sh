#! /bin/bash
echo "Enter an Integer number :"
read Num 
i=2
flag=0
while test $i -le `expr $Num / 2 `
do 
if test `expr $Num % $i ` -eq 0
then
flag=1
fi
i=`expr $i + 1`
done 
if test $flag -eq 1
then
echo " $Num not prime "
else 
echo " $Num is prime"
fi
