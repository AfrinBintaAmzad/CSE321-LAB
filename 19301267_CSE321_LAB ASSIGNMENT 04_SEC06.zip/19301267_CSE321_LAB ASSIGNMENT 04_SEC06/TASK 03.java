import java.util.*;
 
public class T3 {
 public static void main(String args[]){
  
  Scanner sc = new Scanner(System.in);
  System.out.println ("Enter total no of process:");
  int n = sc.nextInt();
  
  System.out.println ("Enter time quantum:");
  int tq = sc.nextInt();
  
  
  int id[] = new int[n];
  int pr[] = new int[n];
  int qr[] = new int[n];
  int at[] = new int[n]; 
  int bt[] = new int[n]; 
  int ct[] = new int[n]; 
  int ta[] = new int[n]; 
  int wt[] = new int[n];
  int btt[] = new int[n];
  int f[] = new int[n];
  int wss = 0, tss = 0;
  int st=0, t=0, prt = 1;
  
  for(int i=0;i<n;++i){
   
   System.out.println ("Enter process " + (i+1) + " arrival time:");
   at[i] = sc.nextInt();
   
   System.out.println ("Enter process " + (i+1) + " brust time:");
   bt[i] = sc.nextInt();
   btt[i] =bt[i];
      
   id[i] = i+1;
   f[i] = 0;
  }
  
//  3 4 0 24 0 3 0 3
  while(true){
    for(int i=0;i<n;++i){
      
      if(f[i] == 0){
        
        if(bt[i] >= tq){
          btt[i] -= tq;
          
          if(btt[i] > 0){  
            f[i] = 0;
            pr[i] = t;
            qr[i] = t + tq;
            t += tq;
          }else if(btt[i] == 0){
            
            f[i] = 1;
            pr[i] = 0;
            qr[i] = t + tq;
            ct[i] = t + tq;
            ta[i] = ct[i];
            if(i==0){
              wt[i] = qr[n-1] - pr[i] - tq;
            }else{
              wt[i] = qr[i-1] - pr[i] - tq;
            }
            t += tq;
          }else if(btt[i] <0){
            btt[i] = 0;
            f[i] = 1;
            pr[i] = 0;
            qr[i] = t + bt[i];
            ct[i] = t + bt[i];
            
            if(i==0){
              wt[i] = qr[n-1];
              ta[i] = qr[n-1]+bt[i];
            }else{
              wt[i] = qr[i-1];
              ta[i] = qr[i-1]+bt[i];
            }
            t += bt[i];
          }
          
        }else{
          btt[i] = 0;
          f[i] = 1;
          pr[i] = t;
          qr[i] = t + bt[i];
          ct[i] = t + bt[i];
          
          if(i==0){
            wt[i] = qr[n-1];
            ta[i] = qr[n-1]+bt[i];
          }else{
            wt[i] = qr[i-1];
            ta[i] = qr[i-1]+bt[i];
          }
          t += bt[i];
        }
      }
    }
    
    if(countArray(f,0) ==0){
      break;
    }
    
  }
  
  
  
  
  System.out.println();
  System.out.println("ID  Completion Time   Turnarond Time  Waiting Time");
  
  for(int i=0;i<n;++i){
   System.out.println("P"+id[i]+"            "+ct[i]+"                "+ta[i]+"                "+wt[i]);
  }
  
  for(int i=0;i<n;++i){
    wss += wt[i];
    tss += ta[i];
  }
  
   System.out.println("Avg Waiting Time:  "+ (wss/n));
   System.out.println("Avg Turnaround Time:  "+ (tss/n));
  
  
 }
 
 public static int getArrayIndex(int[] arr,int value) {
   
   int k=-1;
   for(int i=0;i<arr.length;i++){
     if(arr[i]==value){
       k=i;
       break;
     }
   }
   return k;
 }
 
 public static int countArray(int[] arr, int value){
   int k=0;
   for(int i=0;i<arr.length;i++){
     if(arr[i]==value){
       k++;
     }
   }
   return k;

 }
}

