import java.util.*;
 
public class T2 {
 public static void main(String args[]){
  
  Scanner sc = new Scanner(System.in);
  System.out.println ("Enter total no of process:");
  int n = sc.nextInt();
  
  int id[] = new int[n];
  int pr[] = new int[n];
  int at[] = new int[n]; 
  int bt[] = new int[n]; 
  int ct[] = new int[n]; 
  int ta[] = new int[n]; 
  int wt[] = new int[n]; 
  int f[] = new int[n];
  int wss = 0, tss = 0;
  int st=0, t=0, prt = 1;
 
  for(int i=0;i<n;++i){
   
   System.out.println ("Enter process " + (i+1) + " arrival time:");
   at[i] = sc.nextInt();
   
   System.out.println ("Enter process " + (i+1) + " brust time:");
   bt[i] = sc.nextInt();
   
   System.out.println ("Enter process " + (i+1) + " Priority:");
   pr[i] = sc.nextInt();
   
   id[i] = i+1;
   f[i] = 0;
  }
  
//  5 0 10 3 0 1 1 0 2 4 0 1 5 0 6 2
  while(t!=n){
    int i = getArrayIndex(pr,prt);
    
    ct[i] = st + bt[i];
    ta[i] = ct[i];
    wt[i] = st;
    
    st += bt[i];
    
    pr[i] = -1;
    
    prt++;   
    t++;
  }
  
  System.out.println();
  System.out.println("ID  Completion Time   Turnarond Time  Waiting Time");
  
  for(int i=0;i<n;++i){
   System.out.println("P"+id[i]+"            "+ct[i]+"                "+ta[i]+"                "+wt[i]);
  }
  
  for(int i=0;i<n;++i){
    wss += wt[i];
    tss += ta[i];
  }
  
   System.out.println("Avg Waiting Time:  "+ (wss/n));
   System.out.println("Avg Turnaround Time:  "+ (tss/n));
  
 }
 
 public static int getArrayIndex(int[] arr,int value) {

        int k=0;
        for(int i=0;i<arr.length;i++){

            if(arr[i]==value){
                k=i;
                break;
            }
        }
    return k;
 }
}

