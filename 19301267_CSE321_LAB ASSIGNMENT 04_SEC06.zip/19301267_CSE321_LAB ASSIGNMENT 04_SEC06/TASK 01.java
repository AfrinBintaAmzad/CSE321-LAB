import java.util.*;
 
public class T1 {
 public static void main(String args[]){
  
  Scanner sc = new Scanner(System.in);
  System.out.println ("Enter total no of process:");
  int n = sc.nextInt();
  
  int id[] = new int[n];
  int at[] = new int[n]; 
  int bt[] = new int[n]; 
  int ct[] = new int[n]; 
  int ta[] = new int[n]; 
  int wt[] = new int[n]; 
  int f[] = new int[n];
  int wss = 0, tss = 0;
  int st=0, t=0;
 
  for(int i=0;i<n;++i){
   
   System.out.println ("Enter process " + (i+1) + " arrival time:");
   at[i] = sc.nextInt();
   
   System.out.println ("Enter process " + (i+1) + " brust time:");
   bt[i] = sc.nextInt();
   
   id[i] = i+1;
   f[i] = 0;
  }
  
  while(t!=n){
   int c=n;
   int min=100000000;
    
   for (int i=0; i<n; ++i){
    if ((at[i] <= st) && (f[i] == 0) && (bt[i]<min)){
     min=bt[i];
     c=i;
    }
   }
   
   if (c==n){
    st++;
   
   }else{
    ct[c]=st+bt[c];
    st+=bt[c];
    ta[c]=ct[c]-at[c];
    wt[c]=ta[c]-bt[c];
    f[c]=1;
    t++;
   }
  }
  
  System.out.println();
  System.out.println("ID  Completion Time   Turnarond Time  Waiting Time");
  
  for(int i=0;i<n;++i){
   System.out.println("P"+id[i]+"            "+ct[i]+"                "+ta[i]+"                "+wt[i]);
  }
  
  for(int i=0;i<n;++i){
    wss += wt[i];
    tss += ta[i];
  }
  
   System.out.println("Avg Waiting Time:  "+ (wss/n));
   System.out.println("Avg Turnaround Time:  "+ (tss/n));
 }
}